#include "LiveWindow/LiveWindowStatusListener.h"
#include "Commands/Scheduler.h"

void LiveWindowStatusListener::ValueChanged(ITable* source, const std::string& key, EntryValue value, bool isNew) {
	
}

