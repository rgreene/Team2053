// Copyright (c) National Instruments 2008.  All Rights Reserved.
// Do Not Edit... this file is generated!

#ifndef __chipObjectAliases_h__
#define __chipObjectAliases_h__

#define nInvariantFPGANamespace nFRC_C0EF_1_1_0
#define nRuntimeFPGANamespace nFRC_2012_1_6_4

#endif // __chipObjectAliases_h__
