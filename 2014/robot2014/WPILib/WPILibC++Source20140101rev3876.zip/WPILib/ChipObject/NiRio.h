// Copyright (c) National Instruments 2008.  All Rights Reserved.

#ifndef __NiRio_h__
#define __NiRio_h__

#include "NiFpga.h"
typedef NiFpga_Status tRioStatusCode;

#endif // __NiRio_h__
