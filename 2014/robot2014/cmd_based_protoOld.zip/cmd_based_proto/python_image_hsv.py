import os
import glob
import time
from SimpleCV import *
